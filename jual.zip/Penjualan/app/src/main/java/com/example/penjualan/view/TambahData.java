package com.example.penjualan.view;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;

import androidx.appcompat.app.AppCompatActivity;

import com.example.penjualan.R;
import com.example.penjualan.database.AppDatabase;
import com.example.penjualan.database.DatabaseClient;
import com.example.penjualan.model.ModelDatabase;


public class TambahData extends AppCompatActivity {

    private Toolbar toolbar;
    private EditText etIdKasir, etNama, etAlamat, etNoTelp;
    private Button btnSimpan;
    private AppDatabase appDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tambah_data);

        // Inisialisasi views
        etIdKasir = findViewById(R.id.etIdKasir);
        etNama = findViewById(R.id.etNama);
        etAlamat = findViewById(R.id.etAlamat);
        etNoTelp = findViewById(R.id.etNoTelp);
        btnSimpan = findViewById(R.id.btnSimpan);
        toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // Inisialisasi database
        appDatabase = DatabaseClient.getInstance(getApplicationContext()).getAppDatabase();

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed(); // Aksi kembali ke halaman sebelumnya
            }
        });

        btnSimpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tambahData();
            }
        });
    }

    private void tambahData() {
        String idKasir = etIdKasir.getText().toString().trim();
        String nama = etNama.getText().toString().trim();
        String alamat = etAlamat.getText().toString().trim();
        String noTelp = etNoTelp.getText().toString().trim();

        // Validasi input
        if (idKasir.isEmpty() || nama.isEmpty() || alamat.isEmpty() || noTelp.isEmpty()) {
            Toast.makeText(this, "Mohon isi semua kolom", Toast.LENGTH_SHORT).show();
            return;
        }

        // Buat objek Kasir baru
        ModelDatabase modelDatabase = new ModelDatabase(idKasir, nama, alamat, noTelp);

        // Insert ke database menggunakan AsyncTask atau ViewModel
        new Thread(new Runnable() {
            @Override
            public void run() {
                appDatabase.databaseDao().insert(modelDatabase);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(TambahData.this, "Data ditambahkan", Toast.LENGTH_SHORT).show();
                        // Reset form setelah insert
                        etIdKasir.setText("");
                        etNama.setText("");
                        etAlamat.setText("");
                        etNoTelp.setText("");
                    }
                });
            }
        }).start();
    }
}


