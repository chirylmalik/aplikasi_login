package com.example.penjualan.database;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.example.penjualan.database.dao.DatabaseDao;
import com.example.penjualan.model.ModelDatabase;

@Database(entities = {ModelDatabase.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
    public abstract DatabaseDao databaseDao();
}
