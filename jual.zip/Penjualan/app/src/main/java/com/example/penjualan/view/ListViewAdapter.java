package com.example.penjualan.view;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.lifecycle.LiveData;
import androidx.recyclerview.widget.RecyclerView;

import com.example.penjualan.R;
import com.example.penjualan.model.ModelDatabase;

import java.util.List;

public class ListViewAdapter extends RecyclerView.Adapter<ListViewAdapter.ViewHolder> {

    public interface OnDeleteClickListener {
        void onDeleteClick(int position);
    }

    private Context mContext;
    private List<ModelDatabase> mDataList;
    private ListViewAdapter.OnDeleteClickListener mListener;

    public void setOnDeleteClickListener(ListViewAdapter.OnDeleteClickListener listener){
        mListener = listener;
    }

    public ListViewAdapter(Context context, List<ModelDatabase> dataList) {
        mContext = context;
        mDataList = dataList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.list_item_data, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ModelDatabase data = mDataList.get(position);

        holder.namaTextView.setText(data.getNama());
        holder.idKasirTextView.setText(data.getIdKasir());
        holder.alamatTextView.setText(data.getAlamat());
        holder.noTelpTextView.setText(data.getNoTelp());

        holder.deleteImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int adapterPosition = holder.getAdapterPosition();
                if (adapterPosition != RecyclerView.NO_POSITION) {
                    mListener.onDeleteClick(adapterPosition);
                }
            }
        });

    }

    public void removeItem(int position) {
        mDataList.remove(position);
        notifyItemRemoved(position);
    }

    public void onDeleteClick(int position) {
        mDataList.remove(position);
        notifyItemRemoved(position);
    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView namaTextView;
        public TextView idKasirTextView;
        public TextView alamatTextView;
        public TextView noTelpTextView;
        public ImageView deleteImageView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            namaTextView = itemView.findViewById(R.id.nama);
            idKasirTextView = itemView.findViewById(R.id.idKasir);
            alamatTextView = itemView.findViewById(R.id.alamat);
            noTelpTextView = itemView.findViewById(R.id.noTelp);
            deleteImageView = itemView.findViewById(R.id.delete);
        }
    }
}
