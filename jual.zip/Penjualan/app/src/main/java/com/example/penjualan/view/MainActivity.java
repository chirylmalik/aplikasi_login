package com.example.penjualan.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.penjualan.R;

public class MainActivity extends AppCompatActivity {

    private ImageButton viewButton, addButton;
    private TextView textViewData, textAddData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inisialisasi views
        addButton = findViewById(R.id.addData);
        textAddData = findViewById(R.id.textAddData);
        viewButton = findViewById(R.id.viewData);
        textViewData = findViewById(R.id.textViewData);

        // Set onClickListener untuk ImageButton
        viewButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                navigateToViewData();
            }
        });

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToAddData();
            }
        });

        // Set onClickListener untuk TextView
        textViewData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToViewData();
            }
        });

        textAddData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToAddData();
            }
        });
    }

    // Method untuk navigasi ke halaman tambah data
    private void navigateToViewData(){
        Intent intent = new Intent(MainActivity.this, ListView.class);
        startActivity(intent);
    }
    private void navigateToAddData() {
        Intent intent = new Intent(MainActivity.this, TambahData.class);
        startActivity(intent);
    }
}
