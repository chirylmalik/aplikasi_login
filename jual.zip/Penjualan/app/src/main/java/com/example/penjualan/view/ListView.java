package com.example.penjualan.view;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.lifecycle.LiveData;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.penjualan.R;
import com.example.penjualan.database.AppDatabase;
import com.example.penjualan.database.DatabaseClient;
import com.example.penjualan.model.ModelDatabase;
import com.example.penjualan.view.ListViewAdapter;

import java.util.List;

public class ListView extends AppCompatActivity implements ListViewAdapter.OnDeleteClickListener{

    private RecyclerView recyclerView;
    private ListViewAdapter adapter;
    private List<ModelDatabase> dataList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view);

        recyclerView = findViewById(R.id.rvListData);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Mengambil data dari database
        getDataFromDatabase();

        adapter = new ListViewAdapter(this, dataList);
        recyclerView.setAdapter(adapter);
    }

    private void getDataFromDatabase() {
        // Ambil data dari database menggunakan AsyncTask atau ViewModel
        new Thread(new Runnable() {
            @Override
            public void run() {
                // Mengambil instance dari database
                AppDatabase appDatabase = DatabaseClient.getInstance(getApplicationContext()).getAppDatabase();

                // Mengambil data dari DAO
                dataList = (List<ModelDatabase>) appDatabase.databaseDao().getAll();

                // Menampilkan data di UI
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        adapter = new ListViewAdapter(ListView.this, dataList);
                        recyclerView.setAdapter(adapter);
                        adapter.notifyDataSetChanged(); // Refresh adapter setelah data diubah
                    }
                });
            }
        }).start();
    }

    @Override
    public void onDeleteClick(int position) {
        // Lakukan tindakan penghapusan data di sini
        ModelDatabase deletedItem = dataList.get(position);
        // Hapus item dari database atau daftar data
        dataList.remove(position);
        // Refresh adapter setelah penghapusan
        adapter.notifyItemRemoved(position);
    }

}