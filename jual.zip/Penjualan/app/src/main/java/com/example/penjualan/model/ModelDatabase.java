package com.example.penjualan.model;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "tbl_kasir")
public class ModelDatabase {
    @PrimaryKey
    @NonNull
    private String idKasir;

    private String nama;
    private String alamat;
    private String noTelp;

    public ModelDatabase(@NonNull String idKasir, String nama, String alamat, String noTelp) {
        this.idKasir = idKasir;
        this.nama = nama;
        this.alamat = alamat;
        this.noTelp = noTelp;
    }

    @NonNull
    public String getIdKasir() {
        return idKasir;
    }

    public void setIdKasir(@NonNull String idKasir) {
        this.idKasir = idKasir;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getNoTelp() {
        return noTelp;
    }

    public void setNoTelp(String noTelp) {
        this.noTelp = noTelp;
    }
}
